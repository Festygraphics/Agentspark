import os
import random
import uuid
from pathlib import Path
from typing import List

import assemblyai as aai
import requests
import srt_equalizer
from moviepy.audio.fx.all import volumex
from moviepy.editor import (
    AudioFileClip,
    CompositeAudioClip,
    CompositeVideoClip,
    TextClip,
    VideoFileClip,
    concatenate_videoclips,
)
from moviepy.video.fx.all import crop
from moviepy.video.tools.subtitles import SubtitlesClip

from config import ASSEMBLY_AI_API_KEY, OUTPUT_PATH, SECONDARY_CONTENT_PATH, TEMP_PATH
from utils.audio import get_random_background_song
from moviepy.editor import ColorClip, afx
from moviepy.video.fx.all import fadein, fadeout, resize
from utils.audio import concat_audios
from utils.audio import generate_voiceover
import time


def generate_word_timestamps(audio_path: Path) -> List[dict]:
    """Generate word-level timestamps using AssemblyAI"""
    aai.settings.api_key = ASSEMBLY_AI_API_KEY

    transcriber = aai.Transcriber()
    transcript = transcriber.transcribe(str(audio_path))

    # Extract word-level timestamps
    words = []
    if transcript.words:
        for word in transcript.words:
            words.append({
                'text': word.text,
                'start': word.start / 1000.0,  # Convert from ms to seconds
                'end': word.end / 1000.0,      # Convert from ms to seconds
                'confidence': getattr(word, 'confidence', 1.0)
            })
    
    return words


def generate_subtitles(audio_path: Path) -> Path:
    """Legacy function for backward compatibility"""
    def equalize_subtitles(srt_path: str, max_chars: int = 10) -> None:
        srt_equalizer.equalize_srt_file(srt_path, srt_path, max_chars)

    aai.settings.api_key = ASSEMBLY_AI_API_KEY

    subtitles_id = uuid.uuid4()

    transcriber = aai.Transcriber()

    transcript = transcriber.transcribe(str(audio_path))

    # Save subtitles
    subtitles_path = TEMP_PATH / f"{subtitles_id}.srt"

    subtitles = transcript.export_subtitles_srt()

    with open(subtitles_path, "w") as f:
        f.write(subtitles)

    # Equalize subtitles
    equalize_subtitles(subtitles_path)

    return subtitles_path


def combine_videos(video_paths: List[Path], max_duration: int) -> Path:
    video_id = uuid.uuid4()
    combined_video_path = TEMP_PATH / f"{video_id}.mp4"

    clips = []
    for video_path in video_paths:
        clip = VideoFileClip(str(video_path))
        clip = clip.without_audio()
        # chain the clip to itself as many times as needed to be over max_duration / len(video_paths)
        clip = concatenate_videoclips([clip] * int(max_duration / len(video_paths)))

        clip = clip.subclip(0, max_duration / len(video_paths))
        clip = clip.set_fps(30)

        # Not all videos are same size,
        # so we need to resize them
        clip = crop(
            clip,
            width=int(clip.h / 1920 * 1080),
            height=clip.h,
            x_center=clip.w / 2,
            y_center=clip.h / 2,
        )
        clip = clip.resize((1080, 1920))

        clips.append(clip)

    final_clip = concatenate_videoclips(clips)
    final_clip = final_clip.set_fps(30)
    final_clip.write_videofile(
        str(combined_video_path),
        threads=os.cpu_count(),
        temp_audiofile=str(TEMP_PATH / f"{video_id}.mp3"),
    )

    return combined_video_path


def create_karaoke_subtitles(words: List[dict], video_duration: float) -> List[TextClip]:
    """Create karaoke-style word-by-word subtitle clips with highlighting"""
    subtitle_clips = []
    
    for word_idx, word in enumerate(words):
        # Find when the next word starts (or video ends)
        next_word_start = words[word_idx + 1]['start'] if word_idx + 1 < len(words) else video_duration
        
        # Create highlighted word clip that disappears when next word starts
        highlighted_clip = TextClip(
            word['text'],
            font="fonts/bold_font.ttf",
            fontsize=118,
            color="#FFFF00",  # Bright yellow
            stroke_color="black",
            stroke_width=6,
        ).set_start(word['start']).set_end(min(next_word_start, word['end'] + 0.3)).set_pos(("center", "center"))
        
        subtitle_clips.append(highlighted_clip)
    
    return subtitle_clips


def generate_video_with_karaoke(
    video_paths: List[Path], tts_path: Path
) -> Path:
    """Generate video with karaoke-style word-by-word subtitles"""
    audio = AudioFileClip(str(tts_path))

    combined_video_path = combine_videos(video_paths, audio.duration)

    # Generate word-level timestamps
    words = generate_word_timestamps(tts_path)
    
    # Create karaoke subtitle clips
    subtitle_clips = create_karaoke_subtitles(words, audio.duration)

    # Combine video with karaoke subtitles
    video_clips = [VideoFileClip(str(combined_video_path))]
    video_clips.extend(subtitle_clips)
    
    result = CompositeVideoClip(video_clips)

    # Add the audio
    audio = AudioFileClip(str(tts_path))
    music = AudioFileClip(str(get_random_background_song()))

    music = music.set_duration(audio.duration)

    audio = CompositeAudioClip([audio, volumex(music, 0.07)])

    result = result.set_audio(audio)

    secondary_video = get_secondary_video_clip(result.duration)

    secondary_video = secondary_video.resize(
        (result.w, int(secondary_video.h / secondary_video.w * result.w))
    )

    secondary_video_position = ("center", result.h - secondary_video.h - 160)

    result = CompositeVideoClip(
        [result, secondary_video.set_pos(secondary_video_position)]
    )

    video_id = uuid.uuid4()

    output_video_path = OUTPUT_PATH / f"{video_id}.mp4"

    result.write_videofile(
        str(output_video_path),
        threads=os.cpu_count(),
        temp_audiofile=str(TEMP_PATH / f"{video_id}.mp3"),
    )

    return output_video_path


def generate_video(
    video_paths: List[Path], tts_path: Path, subtitles_path: Path = None
) -> Path:
    """Legacy function - now uses karaoke subtitles by default"""
    # Use new karaoke approach
    return generate_video_with_karaoke(video_paths, tts_path)


def generate_video_legacy(
    video_paths: List[Path], tts_path: Path, subtitles_path: Path
) -> Path:
    """Original implementation kept for fallback"""
    audio = AudioFileClip(str(tts_path))

    combined_video_path = combine_videos(video_paths, audio.duration)

    generator = lambda txt: TextClip(
        txt,
        font=f"fonts/bold_font.ttf",
        fontsize=112,
        color="#FFFFFF",
        stroke_color="black",
        stroke_width=5,
    )

    # Burn the subtitles into the video
    subtitles = SubtitlesClip(str(subtitles_path), generator)
    result = CompositeVideoClip(
        [
            VideoFileClip(str(combined_video_path)),
            subtitles.set_pos(("center", "center")),
        ]
    )

    # Add the audio
    audio = AudioFileClip(str(tts_path))
    music = AudioFileClip(str(get_random_background_song()))

    music = music.set_duration(audio.duration)

    audio = CompositeAudioClip([audio, volumex(music, 0.07)])

    result = result.set_audio(audio)

    secondary_video = get_secondary_video_clip(result.duration)

    secondary_video = secondary_video.resize(
        (result.w, int(secondary_video.h / secondary_video.w * result.w))
    )

    secondary_video_position = ("center", result.h - secondary_video.h - 160)

    result = CompositeVideoClip(
        [result, secondary_video.set_pos(secondary_video_position)]
    )

    video_id = uuid.uuid4()

    output_video_path = OUTPUT_PATH / f"{video_id}.mp4"

    result.write_videofile(
        str(output_video_path),
        threads=os.cpu_count(),
        temp_audiofile=str(TEMP_PATH / f"{video_id}.mp3"),
    )

    return output_video_path


def save_video(video_url: str) -> str:
    video_id = uuid.uuid4()
    video_path = TEMP_PATH / f"{video_id}.mp4"

    with open(video_path, "wb") as f:
        f.write(requests.get(video_url).content)

    return video_path


def get_secondary_video_clip(duration) -> VideoFileClip:
    secondary_videos = list(SECONDARY_CONTENT_PATH.glob("*.mp4"))

    video_path = random.choice(secondary_videos)

    video = VideoFileClip(str(video_path)).without_audio()

    start_time = random.uniform(0, video.duration - duration)

    clip = video.subclip(start_time, start_time + duration)

    clip = clip.set_fps(30)

    return clip


def create_hook_intro(hook_text: str, duration: float = 3.0) -> Path:
    """Create a short intro clip (vertical 9:16) with the hook text and a subtle motion background.

    Returns path to a temporary mp4 file.
    """
    clip_id = uuid.uuid4()
    out_path = TEMP_PATH / f"hook_intro_{clip_id}.mp4"

    # Create a simple animated background using a ColorClip and a zoom effect
    bg = ColorClip(size=(1080, 1920), color=(18, 18, 36)).set_duration(duration)

    txt = TextClip(
        hook_text,
        font="fonts/bold_font.ttf",
        fontsize=120,
        color="#FFFFFF",
        stroke_color="black",
        stroke_width=4,
        method="label",
    ).set_duration(duration).set_pos("center")

    # subtle zoom (resize) animation by changing size over time
    def zoom(get_frame, t):
        return get_frame(t)

    final = CompositeVideoClip([bg, txt])
    final = final.set_fps(30)

    # Add small fade in/out for smooth transition
    final = final.fx(fadein, 0.15).fx(fadeout, 0.15)

    final.write_videofile(str(out_path), threads=os.cpu_count(), fps=30)
    final.close()

    return out_path


def generate_final_video_with_hook(video_paths: List[Path], final_audio_path: Path, hook_duration: float, hook_text: str) -> Path:
    """Assemble final vertical video by prepending a hook intro clip and setting the combined audio.

    video_paths: list of stock clips to be used for the main content (will be combined to match main duration)
    final_audio_path: path to the concatenated hook+main audio
    hook_duration: duration (seconds) of the hook audio
    hook_text: text to render in the intro

    Returns final video path in OUTPUT_PATH
    """
    audio = AudioFileClip(str(final_audio_path))
    total_duration = audio.duration
    main_duration = max(0, total_duration - hook_duration)

    # Create combined main visual for the main_duration
    main_combined_path = combine_videos(video_paths, max_duration=main_duration)

    # Create hook intro visual
    hook_intro_path = create_hook_intro(hook_text, duration=hook_duration)

    # Load clips
    hook_clip = VideoFileClip(str(hook_intro_path)).without_audio()
    main_clip = VideoFileClip(str(main_combined_path)).without_audio()

    # Concatenate intro + main
    final_clip = concatenate_videoclips([hook_clip, main_clip])

    # Add subtitles (karaoke) for the full audio
    words = generate_word_timestamps(final_audio_path)
    subtitle_clips = create_karaoke_subtitles(words, final_clip.duration)

    video_clips = [final_clip]
    video_clips.extend(subtitle_clips)

    result = CompositeVideoClip(video_clips)

    # Add the audio and background music
    music = AudioFileClip(str(get_random_background_song())).set_duration(audio.duration)
    audio_comp = CompositeAudioClip([AudioFileClip(str(final_audio_path)), volumex(music, 0.07)])

    result = result.set_audio(audio_comp)

    # Add secondary video overlay similar to existing function
    secondary_video = get_secondary_video_clip(result.duration)
    secondary_video = secondary_video.resize((result.w, int(secondary_video.h / secondary_video.w * result.w)))
    secondary_video_position = ("center", result.h - secondary_video.h - 160)
    result = CompositeVideoClip([result, secondary_video.set_pos(secondary_video_position)])

    video_id = uuid.uuid4()
    output_video_path = OUTPUT_PATH / f"{video_id}.mp4"

    result.write_videofile(str(output_video_path), threads=os.cpu_count(), temp_audiofile=str(TEMP_PATH / f"{video_id}.mp3"))

    # cleanup
    result.close()
    audio.close()

    return output_video_path


def create_outro_visual(outro_text: str, duration: float = 4.0) -> Path:
    """Create a short outro visual clip (vertical 9:16) with animated text.

    Returns path to an MP4 file in TEMP_PATH.
    """
    outro_id = uuid.uuid4()
    out_path = TEMP_PATH / f"outro_{outro_id}.mp4"

    # Background color clip
    bg = ColorClip(size=(1080, 1920), color=(10, 10, 20)).set_duration(duration)

    # Text: slide-up animation simulated by setting start times with small offsets
    txt = TextClip(
        "👍 Like   🔁 Share   🔔 Subscribe",
        font="fonts/bold_font.ttf",
        fontsize=84,
        color="#FFFFFF",
        stroke_color="black",
        stroke_width=3,
        method="label",
    ).set_duration(duration).set_pos(("center", "60%"))

    # simple fade in for the text
    final = CompositeVideoClip([bg, txt]).set_fps(30)
    final = final.fx(fadein, 0.25)
    final = final.fx(fadeout, 0.25)

    final.write_videofile(str(out_path), threads=os.cpu_count(), fps=30)
    final.close()

    return out_path


def add_outro(final_video_path: Path, outro_text: str = "Like, share, and subscribe for more!", outro_duration: float = 4.0) -> Path:
    """Append an outro clip (voice + visual) to an existing final video file.

    - Generates outro voice via `generate_voiceover` if available; otherwise returns a mock silent audio path.
    - Creates a visual outro via `create_outro_visual`.
    - Concatenates the original video and outro visual, attaches combined audio, and writes a new file to OUTPUT_PATH.

    Returns the Path to the new video file.
    """
    print("Adding outro to video...")

    # Paths
    final_clip = VideoFileClip(str(final_video_path))

    # Generate outro audio (try real TTS, fallback to silent placeholder)
    try:
        outro_audio_path = generate_voiceover(outro_text)
        print("✅ Outro voice generated via TTS.")
    except Exception as e:
        print(f"⚠️ Outro TTS failed or not configured: {e}. Using silent placeholder audio.")
        # Create a short silent audio file as placeholder
        silent_path = TEMP_PATH / f"silent_outro_{int(time.time())}.mp3"
        # create approx. outro_duration seconds of silence using moviepy
        try:
            from moviepy.audio.AudioClip import AudioClip

            def make_silence(t):
                return 0

            clip = AudioClip(make_silence, duration=outro_duration)
            clip.write_audiofile(str(silent_path), fps=44100)
            clip.close()
            outro_audio_path = silent_path
        except Exception:
            # final fallback: no audio file, leave audio None
            outro_audio_path = None

    # Create outro visual
    outro_visual_path = create_outro_visual(outro_text, duration=outro_duration)

    outro_clip = VideoFileClip(str(outro_visual_path)).without_audio()

    # apply simple crossfade transition from main to outro
    try:
        transition_duration = 0.7
        main_clip = final_clip
        # ensure outro fits
        outro_clip = outro_clip.set_start(main_clip.duration - transition_duration)
        # Concatenate with crossfade by using concatenate_videoclips
        combined = concatenate_videoclips([main_clip, outro_clip])
    except Exception:
        combined = concatenate_videoclips([final_clip, outro_clip])

    # Attach audio: combine original audio (if any) with outro audio appended
    try:
        audio_clips = []
        if final_clip.audio:
            audio_clips.append(final_clip.audio)
        if outro_audio_path:
            audio_clips.append(AudioFileClip(str(outro_audio_path)))

        if audio_clips:
            full_audio = CompositeAudioClip(audio_clips)
            # apply a light fade out to the main audio before outro
            combined = combined.set_audio(full_audio)

    except Exception as e:
        print(f"⚠️ Failed to attach outro audio cleanly: {e}")

    # Write final output
    out_id = uuid.uuid4()
    out_path = OUTPUT_PATH / f"{out_id}.mp4"

    combined.write_videofile(str(out_path), threads=os.cpu_count(), temp_audiofile=str(TEMP_PATH / f"{out_id}.mp3"))

    # cleanup
    try:
        combined.close()
        final_clip.close()
        outro_clip.close()
    except Exception:
        pass

    print("✅ Outro added — replace mock TTS with your real API when ready.")
    return out_path
