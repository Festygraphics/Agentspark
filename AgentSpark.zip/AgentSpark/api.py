"""
Backend API (mock-ready)

🔧 API INTEGRATION GUIDE
1️⃣ Trending Topics -> Reddit (free) by default. Replace with Google Trends or other service if desired.
2️⃣ AI Script Generation -> Uses local `utils.llm.get_script` if available (OpenAI). Falls back to a mock generator when key is missing.
3️⃣ Voice Generation (TTS) -> Uses `utils.audio.generate_voiceover` if configured (Gemini TTS). Falls back to a mock TTS that returns a fake audio path.
4️⃣ Video Generation -> Uses `utils.video.generate_video` pipeline where available. For tests we fall back to returning a placeholder video.

Replace API keys in `.env` / environment variables (see `.env.example`). On startup the server prints reminders for any missing real keys.
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
import httpx
import json
from typing import List, Optional
import os
import uuid
import asyncio
import importlib
from pathlib import Path
from config import TOGETHER_API_KEY
import asyncio
import time


async def call_together_api(niche: str, topic: Optional[str]) -> Optional[dict]:
    """Call Together.ai inference endpoint to generate a viral script + hook.

    Returns a dict: {"script": "...", "hook": "..."} or None on failure.
    NOTE: Replace TOGETHER_API_KEY in your .env with your real key.
    """
    if not TOGETHER_API_KEY:
        print("⚠️ TOGETHER_API_KEY not set - skipping Together.ai call.")
        return None

    prompt = (
        f"Generate a short viral YouTube Shorts script and a 2-5 second hook for this topic."
        f"\nNiche: {niche}\nTopic: {topic or niche}\n\nRespond JSON: { {'hook': '...', 'script':'...'} }"
    )

    url = "https://api.together.xyz/inference"
    headers = {"Authorization": f"Bearer {TOGETHER_API_KEY}", "Content-Type": "application/json"}
    payload = {"input": prompt}

    try:
        async with httpx.AsyncClient(timeout=60) as client:
            res = await client.post(url, headers=headers, json=payload)
            if res.status_code >= 400:
                print(f"⚠️ Together.ai API returned {res.status_code}: {res.text}")
                return None
            data = res.json()
            # Try common response shapes
            # If provider wraps output in 'output' or 'result'
            text_out = None
            if isinstance(data, dict):
                # attempt to find textual output
                for k in ("output", "result", "text", "response"):
                    if k in data:
                        text_out = data[k]
                        break
                if not text_out:
                    # fallback: if '0' or first key contains content
                    vals = list(data.values())
                    if vals:
                        text_out = vals[0]
            if not text_out:
                text_out = res.text

            # Try to parse for JSON; if text_out is JSON string, parse it
            if isinstance(text_out, str):
                try:
                    parsed = json.loads(text_out)
                    if isinstance(parsed, dict) and ("script" in parsed or "hook" in parsed):
                        return parsed
                except Exception:
                    pass

            # As a last resort, attempt to split text_out into hook + script by lines
            if isinstance(text_out, str):
                lines = [l.strip() for l in text_out.splitlines() if l.strip()]
                if lines:
                    hook = lines[0]
                    script = "\n".join(lines[1:]) if len(lines) > 1 else text_out
                    return {"hook": hook, "script": script}

    except Exception as e:
        print(f"⚠️ Together.ai call failed: {e}")
    return None

# Lazy imports for optional backend modules (may require API keys/deps)
def safe_import(module_path: str, attr: str = None):
    try:
        module = importlib.import_module(module_path)
        return getattr(module, attr) if attr else module
    except Exception:
        return None

# Try to import optional helpers
get_script_fn = safe_import("utils.llm", "get_script")
generate_hook_fn = safe_import("utils.llm", "generateHook")
generate_video_fn = safe_import("utils.video", "generate_video")
generate_final_video_with_hook_fn = safe_import("utils.video", "generate_final_video_with_hook")
add_outro_fn = safe_import("utils.video", "add_outro")
generate_voiceover_fn = safe_import("utils.audio", "generate_voiceover")
concat_audios_fn = safe_import("utils.audio", "concat_audios")
get_stock_videos_fn = safe_import("utils.stock_videos", "get_stock_videos")
save_metadata_fn = safe_import("utils.metadata", "save_metadata")

app = FastAPI(title="AgentSpark API")

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve static files from the frontend directory
frontend_path = Path(__file__).parent / "frontend"
if frontend_path.exists():
    app.mount("/images", StaticFiles(directory=frontend_path / "images"), name="images")

# In-memory job storage
jobs = {}

class VideoRequest(BaseModel):
    niche: str
    duration: int
    topic: Optional[str] = None
    script: Optional[str] = None

class TrendingTopic(BaseModel):
    title: str
    description: str
    score: float

async def fetch_reddit_trends(subreddit: str) -> List[dict]:
    """Fetch trending posts from a subreddit"""
    async with httpx.AsyncClient() as client:
        response = await client.get(
            f"https://www.reddit.com/r/{subreddit}/hot.json",
            headers={"User-Agent": "AgentSpark/1.0"}
        )
        if response.status_code == 200:
            data = response.json()
            return [
                {
                    "title": post["data"]["title"],
                    "score": post["data"]["score"],
                    "url": post["data"]["url"]
                }
                for post in data["data"]["children"][:5]
            ]
        return []

async def fetch_news_topics(category: str) -> List[dict]:
    """Fetch trending news topics from NEWS_API_KEY"""
    from config import NEWS_API_KEY
    
    if not NEWS_API_KEY:
        return []
    
    # Map niche to news category
    category_map = {
        "Crypto": "business",
        "Tech": "technology",
        "Fitness": "health",
        "Motivation": "general",
        "AI": "technology",
        "Cooking": "general"
    }
    
    news_category = category_map.get(category, "general")
    
    try:
        async with httpx.AsyncClient() as client:
            response = await client.get(
                f"https://newsapi.org/v2/top-headlines?category={news_category}&apiKey={NEWS_API_KEY}&pageSize=5"
            )
            if response.status_code == 200:
                data = response.json()
                return [
                    {
                        "title": article["title"],
                        "description": article.get("description", ""),
                        "score": 100,  # Placeholder score
                        "url": article.get("url", "")
                    }
                    for article in data.get("articles", [])
                    if article.get("title") and article.get("description")
                ]
    except Exception as e:
        print(f"News API error: {e}")
    
    return []

NICHE_SUBREDDITS = {
    "Crypto": ["CryptoCurrency", "CryptoMarkets"],
    "Motivation": ["GetMotivated", "productivity"],
    "Fitness": ["fitness", "bodybuilding"],
    "Tech": ["technology", "gadgets"],
    "AI": ["artificial", "MachineLearning"],
    "Cooking": ["Cooking", "recipes"]
}

@app.get("/api/trending/{niche}")
async def get_trending_topics(niche: str) -> List[TrendingTopic]:
    """Get trending topics for a specific niche from Reddit and News API"""
    if niche not in NICHE_SUBREDDITS:
        raise HTTPException(status_code=400, detail="Invalid niche")
    
    all_trends = []
    
    # Fetch from Reddit
    subreddits = NICHE_SUBREDDITS[niche]
    for subreddit in subreddits:
        trends = await fetch_reddit_trends(subreddit)
        all_trends.extend(trends)
    
    # Also try to fetch from News API
    news_trends = await fetch_news_topics(niche)
    all_trends.extend(news_trends)
    
    # Sort by score and take top 5
    sorted_trends = sorted(all_trends, key=lambda x: x["score"], reverse=True)[:5]
    
    return [
        TrendingTopic(
            title=trend["title"],
            description=trend.get("description", f"Trending with {trend['score']} upvotes"),
            score=trend["score"]
        )
        for trend in sorted_trends
    ]


@app.post("/api/generateScript")
async def generate_script(title: Optional[str] = Query(None)) -> dict:
    """Generate a video script for a given title.

    Behavior:
    - If `utils.llm.get_script` is available (OpenAI present), use it.
    - Otherwise return a mock script suitable for testing and frontend UX.
    """
    if not title:
        raise HTTPException(status_code=400, detail="Missing title parameter")

    # Console reminder for missing real AI key
    if not get_script_fn:
        print("⚠️ Reminder: OpenAI integration not available. Using mock script generator.")
    try:
        if get_script_fn:
            script = get_script_fn(title)
        else:
            # Mock script generator (free and deterministic for testing)
            script = mock_generate_script(title)
        return {"script": script}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def mock_generate_script(topic: str) -> str:
    """Return a short placeholder script for a topic (used when no LLM key present)."""
    sample_templates = [
        f"You won't believe this quick fact about {topic}. Here's what happened...",
        f"This one idea about {topic} changes everything. Here's why...",
        f"Quickly: {topic} just had a major update — here's the short version.",
        f"Most people don't know this secret about {topic}. Let's fix that in 30 seconds.",
    ]
    return random_choice(sample_templates)


def random_choice(lst: list):
    import random

    return random.choice(lst)


@app.post("/api/tts")
async def tts_generate(text: dict) -> dict:
    """Generate or mock a TTS audio file for provided text.

    Request body: { "text": "..." }
    Response: { "audio_path": "/mock/audio_...mp3" }
    """
    body_text = text.get("text") if isinstance(text, dict) else None
    if not body_text:
        raise HTTPException(status_code=400, detail="Missing 'text' in request body")

    # If real TTS function available, use it; otherwise return a mock path
    if generate_voiceover_fn:
        try:
            audio_path = generate_voiceover_fn(body_text)
            # Return a path usable by frontend (served under /api/download or /downloads)
            return {"audio_path": str(audio_path)}
        except Exception as e:
            print(f"⚠️ TTS generation failed: {e}. Falling back to mock audio.")

    # Mock audio file path (frontend should treat as a downloadable path)
    mock_path = f"/downloads/mock_tts_{uuid.uuid4().hex}.mp3"
    print("⚠️ Reminder: Replace mock TTS with a real TTS provider and API key.")
    return {"audio_path": mock_path}

# (Old direct LLM endpoint removed in favor of mock-aware handler above)


async def process_video(job_id: str, niche: str, topic: Optional[str], duration: int, script: Optional[str] = None):
    """Background task to process video generation with mock fallbacks.

    This function prefers an explicitly provided script (from the frontend). If none
    is provided it will try Together.ai, then local LLM, then a mock generator.
    """
    try:
        # Initialize
        script_text: Optional[str] = script if script else None
        hook_text: Optional[str] = None

        # Try Together.ai if configured (only if no explicit script provided)
        together_res = None
        if TOGETHER_API_KEY and not script_text:
            together_res = await call_together_api(niche, topic)

        if not script_text:
            if together_res and isinstance(together_res, dict):
                script_text = together_res.get("script") or together_res.get("text") or mock_generate_script(niche)
                hook_text = together_res.get("hook") or together_res.get("hook_text") if "hook_text" in together_res else together_res.get("hook")
            else:
                # Fall back to local LLM or mock
                if get_script_fn:
                    script_text = get_script_fn(topic or niche)
                else:
                    script_text = mock_generate_script(topic or niche)

        # Ensure we have at least a placeholder script
        if not script_text:
            script_text = mock_generate_script(topic or niche)

        # Get stock videos (if available)
        if get_stock_videos_fn:
            search_terms = script_text.split()[:5]
            stock_videos = get_stock_videos_fn(search_terms)
        else:
            stock_videos = []

        # Generate hook if we still don't have one
        if not hook_text and generate_hook_fn:
            try:
                hook_text = generate_hook_fn(topic or niche)
            except Exception:
                hook_text = None

        # Audio + video pipeline: prefer advanced path when available
        if generate_voiceover_fn and concat_audios_fn and generate_final_video_with_hook_fn:
            try:
                if not hook_text:
                    hook_text = "You won't believe this!"
                hook_audio = generate_voiceover_fn(hook_text)
                main_audio = generate_voiceover_fn(script_text)
                final_audio = concat_audios_fn([hook_audio, main_audio])
                video_path = generate_final_video_with_hook_fn(stock_videos, final_audio, 3.0, hook_text)
            except Exception as e:
                print(f"⚠️ Advanced video pipeline failed: {e}. Falling back to simple flow.")
                if generate_voiceover_fn and generate_video_fn:
                    main_audio = generate_voiceover_fn(script_text)
                    video_path = generate_video_fn(stock_videos, main_audio)
                else:
                    video_path = create_placeholder_video()
        else:
            # Simpler fallbacks
            if generate_voiceover_fn and generate_video_fn:
                main_audio = generate_voiceover_fn(script_text)
                video_path = generate_video_fn(stock_videos, main_audio)
            elif generate_final_video_with_hook_fn and concat_audios_fn and generate_voiceover_fn:
                main_audio = generate_voiceover_fn(script_text)
                video_path = generate_final_video_with_hook_fn(stock_videos, main_audio, 3.0, "")
            else:
                video_path = create_placeholder_video()

        # Add outro to the video
        if add_outro_fn:
            try:
                from pathlib import Path
                outro_text = "Like, share, and subscribe to my channel!"
                final_video_path = add_outro_fn(Path(video_path), outro_text, outro_duration=4.0)
                video_path = str(final_video_path)
                print("✅ Outro added to video")
            except Exception as e:
                print(f"⚠️ Failed to add outro: {e}. Using video without outro.")

        # Save metadata if available (derive a title)
        title_text = topic or (script_text.splitlines()[0] if script_text else f"short-{uuid.uuid4().hex[:6]}")
        if save_metadata_fn:
            try:
                video_file = save_metadata_fn(title_text, script_text, None, script_text, stock_videos, video_path)
                download_url = f"/downloads/{os.path.basename(video_file)}"
            except Exception as e:
                print(f"⚠️ save_metadata failed: {e}")
                download_url = f"/downloads/{os.path.basename(str(video_path))}"
        else:
            download_url = f"/downloads/{os.path.basename(str(video_path))}"

        jobs[job_id] = {"status": "done", "download_url": download_url}
    except Exception as e:
        jobs[job_id] = {"status": "error", "error": str(e)}


def create_placeholder_video() -> str:
    """Create or return a placeholder video path used for testing when rendering isn't available."""
    # Try to use an existing sample file if present
    sample = os.path.join("downloads", "placeholder.mp4")
    if os.path.exists(sample):
        return sample
    # Otherwise create a tiny empty file marker (not a real video)
    marker = os.path.join("downloads", f"placeholder_{uuid.uuid4().hex}.mp4")
    with open(marker, "wb") as f:
        f.write(b"")
    return marker

@app.post("/api/generate_videos")
async def generate_video(
    request: VideoRequest,
    background_tasks: BackgroundTasks
) -> dict:
    """Start video generation process"""
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "pending"}
    
    # Start background processing
    # Pass both niche and topic (if available). Frontend should send 'topic' inside the request body
    topic = getattr(request, "topic", None) if hasattr(request, "topic") else None
    # If frontend sends topic in JSON body, FastAPI will include it; otherwise topic will be None
    background_tasks.add_task(
        process_video,
        job_id=job_id,
        niche=request.niche,
        topic=topic,
        duration=request.duration,
        script=request.script,
    )
    
    return {"job_id": job_id}

@app.get("/api/jobs/{job_id}")
async def get_job_status(job_id: str) -> dict:
    """Get status of a video generation job"""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]

# Serve generated videos
@app.get("/downloads/{filename}")
async def get_video(filename: str):
    """Serve a generated video file"""
    file_path = os.path.join("downloads", filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Video not found")
    return FileResponse(file_path)


@app.get("/api/download/{filename}")
async def api_download(filename: str):
    """API route that serves downloads under /api/download/{filename} for frontend compatibility."""
    file_path = os.path.join("downloads", filename)
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path)


# Serve the frontend HTML file for all non-API routes
@app.get("/{full_path:path}")
async def serve_frontend(full_path: str):
    """Serve the frontend for all non-API routes (SPA routing)."""
    # If this is an API request, skip it (let other routes handle it)
    if full_path.startswith("api/") or full_path.startswith("downloads/"):
        raise HTTPException(status_code=404, detail="Not found")
    
    # Serve static files if they exist
    frontend_file = frontend_path / full_path
    if frontend_file.exists() and full_path.endswith(('.js', '.css', '.txt', '.xml', '.svg', '.png', '.ico')):
        return FileResponse(frontend_file)
    
    # Otherwise, serve the index.html for SPA routing
    index_file = frontend_path / "index.html"
    if index_file.exists():
        return FileResponse(index_file)
    
    raise HTTPException(status_code=404, detail="Frontend not found")


@app.on_event("startup")
async def startup_event():
    # Print integration status and reminders for placeholder API keys
    print("AgentSpark API starting up...")
    if not get_script_fn:
        print("⚠️ OpenAI/LLM not configured - generateScript will use mock responses. Set OPENAI_API_KEY_AUTO_YT_SHORTS in .env to enable real LLM.")
    else:
        print("✅ OpenAI LLM integration detected.")

    if not generate_voiceover_fn:
        print("⚠️ TTS not configured - /api/tts will return mock audio paths. Configure GEMINI_API_KEY or replace generate_voiceover() in utils/audio.py to enable real TTS.")
    else:
        print("✅ TTS integration detected.")

    if not generate_video_fn and not generate_final_video_with_hook_fn:
        print("⚠️ Video rendering pipeline not available. The backend will return placeholder videos for testing.")
    else:
        print("✅ Video rendering pipeline available.")

    print("⚠️ Reminder: Replace placeholder API keys in .env or .env.example before using production providers.")

if __name__ == "__main__":
    import uvicorn
    # Use Railway's PORT environment variable, fallback to 8000 for local development
    port = int(os.environ.get("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)