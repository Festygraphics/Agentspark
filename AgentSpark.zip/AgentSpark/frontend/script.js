// Simple UI interactions for AgentSpark demo with backend integration
// Use relative API base in production (same domain), or configure window.API_BASE
const API_BASE = window.API_BASE || '/api'; // Backend API base URL

const generateBtn = document.getElementById('generateBtn');
const loadingOverlay = document.getElementById('loadingOverlay');
const statusEl = document.getElementById('status');
const resultBox = document.getElementById('resultBox');
const downloadBtn = document.getElementById('downloadBtn');
const adModal = document.getElementById('adModal');
const countdownEl = document.getElementById('countdown');
const continueBtn = document.getElementById('continueBtn');
const closeAd = document.getElementById('closeAd');
const duration = document.getElementById('duration');
const durationLabel = document.getElementById('durationLabel');
const copyBtn = document.getElementById('copyBtn');
const nicheSelect = document.getElementById('nicheSelect');
const backToTopBtn = document.getElementById('backToTop');

let adWatched = false;
let adTimer = null;
let currentDownloadUrl = '/downloads/video.mp4'; // fallback/mock

duration.addEventListener('input', () => {
  durationLabel.textContent = duration.value;
});

// Duration button selection
document.querySelectorAll('.duration-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.duration-btn').forEach(b => {
      b.classList.remove('bg-white', 'text-black');
      b.setAttribute('aria-pressed', 'false');
    });
    btn.classList.add('bg-white', 'text-black');
    btn.setAttribute('aria-pressed', 'true');
    duration.value = btn.dataset.seconds;
  });
});

// Set initial selection
document.querySelectorAll('.duration-btn')[0].classList.add('bg-white', 'text-black');
document.querySelectorAll('.duration-btn')[0].setAttribute('aria-pressed', 'true');

// Back to top button
if (backToTopBtn) {
  backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

/**
 * Backend contract (expected):
 * POST ${API_BASE}/generate_videos
 *   body: { niche: string, duration: number }
 *   success responses:
 *     - { download_url: string }  // immediate result
 *     - { job_id: string }        // background job started
 *
 * If job_id is returned the frontend will poll GET ${API_BASE}/jobs/{job_id}
 * expected response for polling: { status: 'pending'|'done'|'error', download_url?: string, error?: string }
 */

generateBtn.addEventListener('click', async () => {
  const niche = nicheSelect.value;
  const dur = Number(duration.value);

  // show loading
  loadingOverlay.classList.remove('opacity-0');
  loadingOverlay.classList.remove('pointer-events-none');
  statusEl.textContent = 'Submitting generation request...';

  try {
    const res = await fetch(`${API_BASE}/generate_videos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      // include selected topic and optional generated script if present
      body: JSON.stringify({ niche, duration: dur, topic: window.selectedTopic || null, script: window.currentScript || null }),
    });

    if (!res.ok) {
      const txt = await res.text();
      throw new Error(`Server error: ${res.status} ${txt}`);
    }

    const data = await res.json();

    if (data.download_url) {
      // immediate result
      currentDownloadUrl = data.download_url;
      showResult(currentDownloadUrl);
    } else if (data.job_id) {
      // background job: poll
      statusEl.textContent = 'Job submitted. Processing...';
      await pollJob(data.job_id);
    } else {
      // fallback to local mock
      showResult(currentDownloadUrl);
    }
  } catch (err) {
    console.error(err);
    statusEl.textContent = 'Error: ' + (err.message || err);
    // still show UI so user can try download flow with mock
    showResult(currentDownloadUrl);
  } finally {
    loadingOverlay.classList.add('opacity-0');
    loadingOverlay.classList.add('pointer-events-none');
  }
});

async function pollJob(jobId, interval = 3000, timeout = 5 * 60 * 1000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const res = await fetch(`${API_BASE}/jobs/${jobId}`);
      if (!res.ok) throw new Error(`Poll error ${res.status}`);
      const obj = await res.json();
      if (obj.status === 'done' && obj.download_url) {
        currentDownloadUrl = obj.download_url;
        showResult(currentDownloadUrl);
        return;
      }
      if (obj.status === 'error') {
        throw new Error(obj.error || 'Job failed');
      }
    } catch (e) {
      console.warn('Poll attempt failed', e);
    }
    await new Promise(r => setTimeout(r, interval));
  }
  throw new Error('Job polling timed out');
}

function showResult(downloadUrl) {
  const preview = document.getElementById('previewVideo');
  preview.src = downloadUrl;
  resultBox.classList.remove('hidden');
  statusEl.textContent = 'Ready';
}

// When a user selects a niche, fetch trending topics for that niche
nicheSelect.addEventListener('change', async (e) => {
  const niche = e.target.value;
  statusEl.textContent = `Fetching trending topics for ${niche}...`;
  
  try {
    const response = await fetch(`${API_BASE}/trending/${encodeURIComponent(niche)}`);
    if (!response.ok) throw new Error('Failed to fetch trending topics');
    
    const topics = await response.json();
    
    // Show trending topics in the UI
    const topicsHtml = topics.map(topic => `
      <div class="p-4 rounded-lg glass-card mb-4 cursor-pointer hover:shadow-neon transition-shadow"
           onclick="selectTopic('${encodeURIComponent(topic.title)}')">
        <h3 class="font-semibold">${topic.title}</h3>
        <p class="text-sm text-white/70">${topic.description}</p>
      </div>
    `).join('');
    
    // Insert topics before the duration selection
    const topicsContainer = document.createElement('div');
    topicsContainer.id = 'trending-topics';
    topicsContainer.className = 'space-y-4 my-6';
    topicsContainer.innerHTML = `
      <label class="text-sm text-white/80">Trending Topics</label>
      <div class="space-y-2">
        ${topicsHtml}
      </div>
    `;
    
    // Remove existing topics container if any
    const existingTopics = document.getElementById('trending-topics');
    if (existingTopics) existingTopics.remove();
    
    // Insert new topics before duration selection
    const durationDiv = document.querySelector('[id="duration"]').parentElement;
    durationDiv.parentElement.insertBefore(topicsContainer, durationDiv);
    
    statusEl.textContent = `Selected niche: ${niche}. Click a trending topic to use it.`;
  } catch (err) {
    console.error('Failed to fetch trending topics:', err);
    statusEl.textContent = `Error loading trending topics: ${err.message}`;
  }
  
  // Hide previous result so user knows to generate a fresh video
  resultBox.classList.add('hidden');
});

// Handle topic selection
async function selectTopic(encodedTitle) {
  const title = decodeURIComponent(encodedTitle);
  statusEl.textContent = 'Generating script...';
  
  try {
    const response = await fetch(`${API_BASE}/generateScript?title=${encodeURIComponent(title)}`, {
      method: 'POST'
    });
    
    if (!response.ok) throw new Error('Failed to generate script');
    const data = await response.json();
    
  // Store the script for video generation
  window.currentScript = data.script;
  // Keep track of the selected topic so we can pass it when generating the video
  window.selectedTopic = title;
  statusEl.textContent = 'Script ready! Choose duration and click Generate to create video.';
  } catch (err) {
    console.error('Failed to generate script:', err);
    statusEl.textContent = `Error generating script: ${err.message}`;
  }
}

downloadBtn.addEventListener('click', () => {
  // open ad modal and start countdown
  adWatched = false;
  adModal.classList.remove('hidden');
  continueBtn.classList.add('hidden');
  let seconds = 5;
  countdownEl.textContent = seconds;

  // prevent leaving early
  window.addEventListener('beforeunload', beforeUnloadHandler);

  adTimer = setInterval(() => {
    seconds -= 1;
    countdownEl.textContent = seconds;
    if (seconds <= 0) {
      clearInterval(adTimer);
      continueBtn.classList.remove('hidden');
      adWatched = true;
      window.removeEventListener('beforeunload', beforeUnloadHandler);
    }
  }, 1000);
});

continueBtn.addEventListener('click', () => {
  if (!adWatched) return;
  // close modal and trigger download
  adModal.classList.add('hidden');
  triggerDownload(currentDownloadUrl);
});

closeAd.addEventListener('click', () => {
  // if closed early, block download
  if (!adWatched) {
    alert('You must watch the short ad to download your video.');
    return;
  }
  adModal.classList.add('hidden');
});

function beforeUnloadHandler(e) {
  // Notify user if they try to close/refresh while ad is playing
  e.preventDefault();
  e.returnValue = '';
}

function triggerDownload(url) {
  if (!url) {
    showToast('No download URL available');
    return;
  }
  // simple download trigger; in a real app you might do a signed fetch or redirect
  const a = document.createElement('a');
  a.href = url;
  a.download = 'agent-spark-short.mp4';
  document.body.appendChild(a);
  a.click();
  a.remove();
}

// Copy USDT address and show a small "love" animation that thanks the user
copyBtn.addEventListener('click', async () => {
  // read the address displayed under the QR (so the displayed address is authoritative)
  const addrEl = document.getElementById('usdtAddress');
  const addr = addrEl ? addrEl.innerText.trim() : '';

  if (!addr) {
    showToast('No address available to copy.');
    return;
  }

  try {
    await navigator.clipboard.writeText(addr);
    showSupportAnimation();
  } catch (e) {
    console.error('Copy failed', e);
    showToast('Copy failed.');
  }
});

// Create and show a small animated "love" toast near the QR when a user copies the address
function showSupportAnimation() {
  // inject styles once
  if (!document.getElementById('support-animation-styles')) {
    const style = document.createElement('style');
    style.id = 'support-animation-styles';
    style.innerHTML = `
      @keyframes supportPop { 0% { transform: scale(0.8); opacity: 0 } 50% { transform: scale(1.06); opacity: 1 } 100% { transform: scale(1); opacity: 1 } }
      @keyframes floatUp { 0% { transform: translateY(0); opacity: 1 } 100% { transform: translateY(-40px); opacity: 0 } }
      .love-toast { position: fixed; right: 2rem; bottom: 6.5rem; z-index: 60; pointer-events: none; display:flex; align-items:center; gap:0.6rem; background: rgba(255,255,255,0.06); color: white; padding: 0.6rem 0.9rem; border-radius: 12px; backdrop-filter: blur(6px); border: 1px solid rgba(255,255,255,0.06); box-shadow: 0 8px 24px rgba(99,102,241,0.12); animation: supportPop 360ms ease-out forwards; }
      .love-heart { font-size: 1.2rem; transform-origin: center; animation: floatUp 1800ms ease-out forwards; }
      .love-text { font-size: 0.95rem; font-weight: 600; }
    `;
    document.head.appendChild(style);
  }

  const toast = document.createElement('div');
  toast.className = 'love-toast';
  toast.innerHTML = `<div class="love-heart">💚</div><div class="love-text">Thanks — your support counts!</div>`;
  document.body.appendChild(toast);

  // auto-fade after 2.2s
  setTimeout(() => {
    // start floatUp animation on the heart and fade the whole toast
    const heart = toast.querySelector('.love-heart');
    if (heart) heart.style.animation = 'floatUp 1200ms ease-out forwards';
    toast.style.transition = 'opacity 600ms ease, transform 600ms ease';
    toast.style.opacity = '0';
  }, 1400);

  setTimeout(() => toast.remove(), 2200);
}

// Simple toast
function showToast(text) {
  const t = document.createElement('div');
  t.textContent = text;
  t.className = 'fixed bottom-6 right-6 bg-white/6 text-white/90 px-4 py-2 rounded shadow-glow';
  document.body.appendChild(t);
  setTimeout(() => t.classList.add('opacity-0'), 2500);
  setTimeout(() => t.remove(), 3000);
}
