# 🚀 AgentSpark - Quick Setup Guide

## ✅ What's Been Implemented

### 1. **Fully Functional Backend API** (`api.py`)
- ✅ Portrait video generation (1080x1920) for YouTube Shorts
- ✅ Trending topics from Reddit + News API
- ✅ Viral hook generation + main script
- ✅ Automatic outro: "Like, share, and subscribe!"
- ✅ Background job processing with status polling
- ✅ Comprehensive error handling with fallbacks

### 2. **Connected Frontend** (`frontend/script.js`)
- ✅ Fetches trending topics when niche is selected
- ✅ Generates script from selected topic
- ✅ Background job polling with progress updates
- ✅ 5-second ad modal before download
- ✅ Full video download flow

### 3. **Production-Ready Features**
- ✅ Responsive UI (mobile + desktop)
- ✅ Loading indicators and progress bars
- ✅ Error handling and user-friendly messages
- ✅ Ad monetization integration
- ✅ Support developer section with USDT QR

## 🔧 Setup Instructions

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 2: Add Required Directories

The following directories need to be created:

```bash
mkdir music secondary_video temp downloads output
```

**Important:** Add sample files to these directories:

- `music/` - Add MP3 background music files
- `secondary_video/` - Add MP4 secondary content overlays
- `fonts/` - Already contains bold_font.ttf

### Step 3: Configure API Keys

Create a `.env` file in the project root:

```bash
# Required API Keys
OPENAI_API_KEY_AUTO_YT_SHORTS=sk-your-key-here
PEXELS_API_KEY=your-pexels-key-here
GEMINI_API_KEY=your-gemini-key-here

# Optional but recommended
NEWS_API_KEY=your-news-api-key-here
ASSEMBLY_AI_API_KEY=your-assembly-ai-key-here
TOGETHER_API_KEY=your-together-ai-key-here

# Configuration
OPENAI_MODEL=gpt-4-turbo-preview
GEMINI_TTS_MODEL=gemini-2.5-flash-preview-tts
```

### Step 4: Add Sample Media Files

#### Background Music (`music/` folder)
Add at least 2-3 royalty-free instrumental MP3 files for background music.

#### Secondary Videos (`secondary_video/` folder)
Add short video clips (preferably vertical 1080x1920) that will be overlaid on the final video.

### Step 5: Start the Application

#### Option 1: Run Backend Only
```bash
python api.py
```
Backend will be available at: `http://localhost:8000`

#### Option 2: Run with Legacy Script
```bash
RUN_ONCE=true python main.py
```

#### Option 3: Docker
```bash
docker-compose up
```

### Step 6: Open Frontend

Open `frontend/index.html` in your browser, or:
- Local: `file:///path/to/frontend/index.html`
- Or serve with a simple HTTP server: `python -m http.server 8080`

## 📋 API Endpoints Summary

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/trending/{niche}` | GET | Fetch trending topics for niche |
| `/api/generateScript?title=...` | POST | Generate viral script |
| `/api/generate_videos` | POST | Start video generation |
| `/api/jobs/{job_id}` | GET | Check job status |
| `/downloads/{filename}` | GET | Download video |
| `/api/download/{filename}` | GET | Download video (alt) |

## 🎬 How to Use

1. **Open frontend** (`frontend/index.html`)
2. **Select a niche** (Crypto, Motivation, Fitness, etc.)
3. **View trending topics** (automatically fetched)
4. **Click on a topic** to generate script
5. **Select video duration** (30s, 1m, 2m)
6. **Click "Generate Video"**
7. **Wait for processing** (progress shown)
8. **Preview your video**
9. **Click "Download"**
10. **Watch 5-second ad**
11. **Complete ad** → Video downloads!

## 🎨 Video Structure

Every generated video follows this structure:

1. **Viral Hook (2-5 seconds)**
   - Attention-grabbing opener
   - High contrast visuals
   - Text overlay
   
2. **Main Content (15-60+ seconds)**
   - AI-generated script
   - Stock footage from Pexels
   - Karaoke-style subtitles
   - Background music
   - Secondary video overlay
   
3. **Outro (4 seconds)**
   - "Like, share, and subscribe!" message
   - Call-to-action overlay

**Output Format:**
- Resolution: 1080x1920 (portrait)
- FPS: 30
- Format: MP4
- Ready for YouTube Shorts, TikTok, Instagram Reels

## 🐛 Troubleshooting

### "No stock videos found"
- Verify `PEXELS_API_KEY` is set
- Check internet connection

### "TTS generation failed"
- Set `GEMINI_API_KEY` or install gTTS: `pip install gtts`

### "OpenAI API error"
- Verify `OPENAI_API_KEY_AUTO_YT_SHORTS` is correct
- Check API quota

### Video generation timeout
- Increase timeout in `frontend/script.js` (line 85)
- Check backend logs for errors

## 📦 Deployment

### Render.com

1. Connect GitHub repository
2. Set environment variables in Render dashboard
3. Build command: `pip install -r requirements.txt`
4. Start command: `python api.py`
5. Update frontend `index.html` line 376 to use Render URL

### Netlify/Vercel

1. Deploy static frontend to Netlify/Vercel
2. Use Render for backend API
3. Update API_BASE in frontend HTML

## 📝 File Locations for Customization

- **UI Styles**: `frontend/index.html` (lines 60-160)
- **Viral Hook Prompt**: `utils/llm.py` (line 360-396)
- **Ad Logic**: `frontend/script.js` (lines 188-231)
- **Ad Content**: `frontend/index.html` (lines 354-371)
- **Video Outro Text**: `api.py` (line 383)

## 🔑 API Keys Sources

1. **OpenAI**: https://platform.openai.com/api-keys
2. **Pexels**: https://www.pexels.com/api/
3. **Gemini**: https://ai.google.dev/
4. **News API**: https://newsapi.org/
5. **Assembly AI**: https://www.assemblyai.com/
6. **Together AI**: https://together.ai/

## 🎯 Next Steps

1. ✅ Add your API keys to `.env`
2. ✅ Add background music to `music/` folder
3. ✅ Add secondary videos to `secondary_video/` folder
4. ✅ Test the full workflow
5. ✅ Deploy to Render/Netlify
6. ✅ Customize UI and prompts

## 📚 Documentation

See `API_DOCUMENTATION.md` for detailed API reference.

---

**🎉 Your Auto YouTube Shorts Generator is ready to use!**

For questions or support, email: agentspark.site@gmail.com
