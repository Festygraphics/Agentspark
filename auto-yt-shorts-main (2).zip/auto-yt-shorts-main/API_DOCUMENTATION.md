# AgentSpark - Auto YouTube Shorts Generator

## 📋 Overview

AgentSpark is a fully automated YouTube Shorts generator that creates viral short-form videos with AI-generated scripts, voiceovers, stock footage, and subtitles.

## 🔌 Backend API Endpoints

### Base URL
```
Production: https://your-app.onrender.com
Local: http://localhost:8000
```

### 1. Trending Topics Endpoint
```
GET /api/trending/{niche}
```

**Description:** Fetches trending topics for a specific niche from Reddit and News API.

**Parameters:**
- `niche` (path, required): One of: "Crypto", "Motivation", "Fitness", "Tech", "AI", "Cooking"

**Response:**
```json
[
  {
    "title": "String",
    "description": "String",
    "score": 100.0
  }
]
```

**Example:**
```bash
curl http://localhost:8000/api/trending/Crypto
```

---

### 2. Generate Script Endpoint
```
POST /api/generateScript
```

**Description:** Generates a viral script for a given topic using OpenAI.

**Query Parameters:**
- `title` (required): The topic title to generate a script for

**Response:**
```json
{
  "script": "You won't believe this..."
}
```

**Example:**
```bash
curl -X POST "http://localhost:8000/api/generateScript?title=Bitcoin%20surge"
```

---

### 3. Generate Videos Endpoint
```
POST /api/generate_videos
```

**Description:** Starts the video generation process in the background.

**Request Body:**
```json
{
  "niche": "Crypto",
  "duration": 30,
  "topic": "optional topic title",
  "script": "optional pre-generated script"
}
```

**Response:**
```json
{
  "job_id": "uuid-string"
}
```

**Example:**
```bash
curl -X POST http://localhost:8000/api/generate_videos \
  -H "Content-Type: application/json" \
  -d '{"niche":"Crypto","duration":30}'
```

---

### 4. Check Job Status
```
GET /api/jobs/{job_id}
```

**Description:** Check the status of a video generation job.

**Response:**
```json
{
  "status": "pending" | "done" | "error",
  "download_url": "/downloads/video.mp4",
  "error": "error message if status is error"
}
```

**Example:**
```bash
curl http://localhost:8000/api/jobs/abc123
```

---

### 5. Download Video
```
GET /downloads/{filename}
```

**Description:** Downloads a generated video file.

**Example:**
```
http://localhost:8000/downloads/video_abc123.mp4
```

---

## 🔑 API Keys Usage

### Required API Keys

1. **OPENAI_API_KEY_AUTO_YT_SHORTS** - Used for:
   - Script generation (`utils/llm.py`)
   - Hook generation
   - Title optimization
   - Description generation

2. **PEXELS_API_KEY** - Used for:
   - Fetching stock videos based on search terms (`utils/stock_videos.py`)

3. **GEMINI_API_KEY** - Used for:
   - Text-to-speech voice generation (`utils/audio.py`)
   - Falls back to gTTS if not configured

### Optional API Keys

4. **NEWS_API_KEY** - Used for:
   - Fetching trending news topics in addition to Reddit
   - Located in: `api.py` - `fetch_news_topics()` function

5. **TOGETHER_API_KEY** - Used for:
   - Alternative viral script and hook generation
   - Located in: `api.py` - `call_together_api()` function

6. **ASSEMBLY_AI_API_KEY** - Used for:
   - Word-level timestamps for karaoke subtitles (`utils/video.py`)
   - Optional but recommended for better subtitles

---

## 🎬 Video Generation Pipeline

### Flow:
1. **User selects niche** → Fetches trending topics from Reddit + News API
2. **User selects topic** → Generates viral script with OpenAI
3. **User clicks Generate** → Sends request to `/api/generate_videos`
4. **Backend processes:**
   - Generates viral hook (2-5 seconds)
   - Generates main script
   - Fetches stock videos from Pexels
   - Creates voiceovers (hook + main)
   - Combines videos with audio
   - Adds outro: "Like, share, and subscribe!"
   - Final video in portrait format (1080x1920)
5. **Frontend polls job status** → Shows video when ready
6. **User clicks Download** → Shows ad modal (5 seconds)
7. **User completes ad** → Video downloads

---

## 📁 Directory Structure

```
auto-yt-shorts-main/
├── api.py                    # FastAPI backend
├── config.py                 # Configuration and API keys
├── main.py                   # Main script runner (legacy)
├── requirements.txt          # Python dependencies
├── downloads/                # Generated videos (output)
├── temp/                     # Temporary files during processing
├── music/                    # Background music files (required)
├── secondary_video/         # Secondary video overlays (required)
├── frontend/
│   ├── index.html           # Main UI
│   ├── script.js            # Frontend logic
│   └── images/              # Static assets
└── utils/
    ├── audio.py             # TTS and audio processing
    ├── llm.py               # OpenAI/LLM integration
    ├── video.py             # Video editing and rendering
    ├── stock_videos.py      # Pexels integration
    └── metadata.py          # Video metadata storage
```

---

## 🎨 UI Customization

### Modify UI Styles
**File:** `frontend/index.html`
- Lines 60-160: CSS styles
- Modify colors, fonts, animations
- Glass card styling: `.glass-card`
- Neon effects: `.shadow-neon`

### Modify Viral Hook Prompts
**File:** `utils/llm.py`
- Line 360-396: `generateHook()` function
- Adjust prompt to change hook style and length

### Modify Ad Logic
**File:** `frontend/script.js`
- Lines 188-231: Ad modal and countdown
- Change countdown duration (line 193): `let seconds = 5;`
- Modify ad content in `frontend/index.html` (lines 354-371)

---

## 🚀 Deployment

### For Render.com:

1. **Set Environment Variables:**
```
OPENAI_API_KEY_AUTO_YT_SHORTS=your_key
PEXELS_API_KEY=your_key
GEMINI_API_KEY=your_key
NEWS_API_KEY=your_key (optional)
```

2. **Add Build Command:**
```bash
pip install -r requirements.txt
```

3. **Add Start Command:**
```bash
python api.py
```

4. **Update Frontend API Base:**
In `frontend/index.html` line 376:
```javascript
window.API_BASE = 'https://your-app.onrender.com/api';
```

### For Netlify:

1. Build static frontend
2. Use Netlify Functions for backend API
3. Set environment variables in Netlify dashboard

---

## 📝 Error Handling

The system includes comprehensive error handling:

- **Missing API Keys:** Falls back to mock implementations
- **API Failures:** User-friendly error messages
- **Video Generation Errors:** Logged with warnings
- **Network Issues:** Timeout handling and retries

---

## 🧪 Testing

### Test Full Workflow:

```bash
# 1. Start backend
python api.py

# 2. Open frontend
# Navigate to frontend/index.html

# 3. Select niche → Crypto
# 4. Click on a trending topic
# 5. Wait for script generation
# 6. Click "Generate Video"
# 7. Wait for video processing (check job status)
# 8. Click "Download"
# 9. Watch 5-second ad
# 10. Complete ad and download video
```

---

## 📊 Performance Optimizations

- **Parallel Processing:** Videos generated in background
- **Portrait Format:** All videos are 1080x1920 (YouTube Shorts ready)
- **Caching:** Stock videos cached in temp directory
- **Progress Tracking:** Real-time job status updates

---

## 🔧 Troubleshooting

### Issue: "No stock videos found"
**Solution:** Check PEXELS_API_KEY and ensure internet connection

### Issue: "TTS generation failed"
**Solution:** Configure GEMINI_API_KEY or install gTTS as fallback

### Issue: "OpenAI API error"
**Solution:** Verify OPENAI_API_KEY_AUTO_YT_SHORTS is set correctly

### Issue: Video generation timeout
**Solution:** Increase timeout in `script.js` (line 85): `timeout = 5 * 60 * 1000`

---

## 📄 License

MIT License - See LICENSE file

---

## 🤝 Support

- Email: agentspark.site@gmail.com
- Support Developer: See USDT QR code in UI
