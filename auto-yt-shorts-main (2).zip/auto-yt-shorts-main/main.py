import logging

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.cron import CronTrigger
from tqdm import tqdm

from config import CRON_SCHEDULE, RUN_ONCE, VIDEO_COUNT
from utils.audio import generate_voiceover, concat_audios
from utils.llm import (
    get_description,
    get_most_engaging_titles,
    get_script,
    get_search_terms,
    get_titles,
    get_topic,
    generateHook,
)
from utils.metadata import save_metadata
from utils.notifications import send_error_notification, send_success_notification
from utils.stock_videos import get_stock_videos
from utils.video import generate_video, generate_final_video_with_hook, add_outro
from utils.yt import prep_for_manual_upload

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def generate_video_data(title):
    logger.info("[Generated Title]")
    logger.info(title)

    script = get_script(title)
    logger.info("[Generated Script]")
    logger.info(script)

    description = get_description(title, script)
    logger.info("[Generated Description]")
    logger.info(description)

    search_terms = get_search_terms(title, script)
    logger.info("[Generated Search Terms]")
    logger.info(search_terms)

    stock_videos = get_stock_videos(search_terms)
    logger.info("[Generated Stock Videos]")

    # --- VIRAL HOOK INTEGRATION ---
    # Generate a short hook and corresponding TTS, then concatenate with main voiceover
    try:
        hook_text = generateHook(title)
        logger.info(f"[Generated Hook] {hook_text}")

        hook_audio = generate_voiceover(hook_text)
        logger.info(f"[Generated Hook Audio] {hook_audio}")

        main_audio = generate_voiceover(script)
        logger.info(f"[Generated Main Audio] {main_audio}")

        # Concatenate hook + main audio into a single audio file
        final_audio = concat_audios([hook_audio, main_audio])
        logger.info(f"[Concatenated Audio] {final_audio}")

        # Create the final video by prepending a visual hook and combining audio/video
        # Determine hook duration from the hook audio file
        try:
            from moviepy.editor import AudioFileClip

            hook_dur = AudioFileClip(str(hook_audio)).duration
        except Exception:
            hook_dur = 3.0

        final_video = generate_final_video_with_hook(
            stock_videos, final_audio, hook_dur, hook_text
        )
        logger.info(f"[Generated Final Video with Hook] {final_video}")
    except Exception as e:
        logger.warning(f"Hook integration failed, falling back: {e}")
        # Fallback: generate main voiceover and video as before
        main_audio = generate_voiceover(script)
        final_video = generate_video(stock_videos, main_audio)

    return title, description, script, search_terms, stock_videos, final_video


def generate_videos(n: int = 4) -> None:
    try:
        topic = get_topic()

        logger.info("[Generated Topic]")
        logger.info(topic)

        possible_titles = get_titles(topic)
        logger.info("[Generated Possible Titles]")
        logger.info(possible_titles)

        titles = get_most_engaging_titles(possible_titles, n)

        videos_generated = 0
        for title in tqdm(titles, desc="Generating videos"):
            try:
                (
                    title,
                    description,
                    script,
                    search_terms,
                    stock_videos,
                    final_video,
                ) = generate_video_data(title)

                logging.debug(f"Title: {title}")
                logging.debug(f"Description: {description}")
                logging.debug(f"Script: {script}")
                logging.debug(f"Search terms: {search_terms}")
                logging.debug(f"Stock videos: {stock_videos}")
                logging.debug(f"Final video path: {final_video}")

                # Append outro to the final video (modular helper)
                try:
                    final_with_outro = add_outro(final_video)
                    logger.info("[Appended Outro]")
                except Exception as e:
                    logger.warning(f"Failed to append outro, using original video: {e}")
                    final_with_outro = final_video

                new_video_file = save_metadata(
                    title, description, None, script, search_terms, final_with_outro
                )
                logger.info("[Saved Video]")

                # Automatic YouTube upload removed per user request.
                # Prepare files for manual upload (copies video + creates description .txt)
                try:
                    prep_for_manual_upload(new_video_file, title, description)
                    logger.info("[Prepared for manual upload]")
                except Exception as e:
                    logger.warning(f"Failed to prepare manual upload: {e}")
                videos_generated += 1

            except Exception as e:
                error_msg = f"Failed to generate/upload video '{title}'"
                logger.error(f"{error_msg}: {e}")
                send_error_notification(error_msg, e, "Video Generation")

        if videos_generated > 0:
            success_msg = (
                f"Successfully generated and uploaded {videos_generated} video(s)"
            )
            logger.info(success_msg)
            send_success_notification(success_msg, "Video Generation")
        else:
            error_msg = "No videos were successfully generated"
            logger.error(error_msg)
            send_error_notification(error_msg, context="Video Generation")

    except Exception as e:
        error_msg = "Failed to start video generation process"
        logger.error(f"{error_msg}: {e}")
        send_error_notification(error_msg, e, "Video Generation")


def main():
    cron_schedule = CRON_SCHEDULE
    run_once = RUN_ONCE
    video_count = VIDEO_COUNT

    if run_once:
        logger.info("RUN_ONCE is enabled, generating videos immediately...")
        generate_videos(video_count)
        logger.info("Video generation completed. Exiting.")
        return

    logger.info(f"Starting scheduler with cron schedule: {cron_schedule}")
    scheduler = BlockingScheduler()

    trigger = CronTrigger.from_crontab(cron_schedule)
    scheduler.add_job(
        func=generate_videos, trigger=trigger, args=[video_count], id="video_generation"
    )

    try:
        scheduler.start()
    except KeyboardInterrupt:
        logger.info("Received interrupt signal, shutting down...")
        scheduler.shutdown()
    except Exception as e:
        error_msg = "Scheduler failed unexpectedly"
        logger.error(f"{error_msg}: {e}")
        send_error_notification(error_msg, e, "Scheduler")


if __name__ == "__main__":
    main()
